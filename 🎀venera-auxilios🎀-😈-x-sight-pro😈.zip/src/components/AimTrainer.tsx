import React, { useEffect, useRef, useState, useCallback } from 'react';
import { CrosshairConfig } from '../types';
import { Crosshair } from './Crosshair';
import { Zap } from 'lucide-react';
import { motion } from 'motion/react';

interface Target {
  id: number;
  x: number;
  y: number;
  radius: number;
  vx: number;
  vy: number;
}

interface AimTrainerProps {
  config: CrosshairConfig;
}

export const AimTrainer: React.FC<AimTrainerProps> = ({ config }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [targets, setTargets] = useState<Target[]>([]);
  const [score, setScore] = useState(0);
  const [hits, setHits] = useState(0);
  const [misses, setMisses] = useState(0);
  const [mode, setMode] = useState<'flick' | 'track'>('flick');
  const requestRef = useRef<number>(null);

  const spawnTarget = useCallback(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const radius = mode === 'flick' ? 20 : 30;
    const x = Math.random() * (canvas.width - radius * 2) + radius;
    const y = Math.random() * (canvas.height - radius * 2) + radius;
    const vx = mode === 'track' ? (Math.random() - 0.5) * 4 : 0;
    const vy = mode === 'track' ? (Math.random() - 0.5) * 4 : 0;

    const newTarget: Target = {
      id: Date.now(),
      x,
      y,
      radius,
      vx,
      vy,
    };

    if (mode === 'flick') {
      setTargets([newTarget]);
    } else {
      setTargets((prev) => [...prev, newTarget].slice(-3));
    }
  }, [mode]);

  useEffect(() => {
    spawnTarget();
  }, [spawnTarget]);

  const animate = useCallback(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    setTargets((prevTargets) => {
      return prevTargets.map((t) => {
        let nx = t.x + t.vx;
        let ny = t.y + t.vy;

        if (nx - t.radius < 0 || nx + t.radius > canvas.width) t.vx *= -1;
        if (ny - t.radius < 0 || ny + t.radius > canvas.height) t.vy *= -1;

        return { ...t, x: nx, y: ny };
      });
    });

    requestRef.current = requestAnimationFrame(animate);
  }, []);

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [animate]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const render = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      targets.forEach((t) => {
        ctx.beginPath();
        ctx.arc(t.x, t.y, t.radius, 0, Math.PI * 2);
        ctx.fillStyle = mode === 'flick' ? '#ef4444' : '#3b82f6';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.closePath();

        // ESP Overlay (Simulated AI Detection)
        if (config.espEnabled) {
          ctx.strokeStyle = '#ef4444';
          ctx.lineWidth = 1;
          const boxSize = t.radius * 2.5;
          ctx.strokeRect(t.x - boxSize/2, t.y - boxSize/2, boxSize, boxSize);
          
          // AI Label
          ctx.fillStyle = '#ef4444';
          ctx.font = 'bold 8px Helvetica';
          ctx.fillText('TARGET_DETECTED', t.x - boxSize/2, t.y - boxSize/2 - 4);
        }
      });
    };

    render();
  }, [targets, mode]);

  const handleCanvasPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (config.preciseTouch) {
      // Immediate response for precise touch
      processClick(e.clientX, e.clientY);
    }
  };

  const processClick = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    let hit = false;
    setTargets((prev) => {
      const remaining = prev.filter((t) => {
        const dist = Math.sqrt((x - t.x) ** 2 + (y - t.y) ** 2);
        // Aim Stabilizer: 25% proximity boost
        const effectiveRadius = config.aimStabilizer ? t.radius * 1.25 : t.radius;
        
        if (dist <= effectiveRadius) {
          hit = true;
          return false;
        }
        return true;
      });
      return remaining;
    });

    if (hit) {
      setScore((s) => s + 100);
      setHits((h) => h + 1);
      spawnTarget();
    } else {
      setMisses((m) => m + 1);
    }
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!config.preciseTouch) {
      processClick(e.clientX, e.clientY);
    }
  };

  return (
    <div className={`relative w-full h-full flex flex-col items-center justify-center rounded-xl overflow-hidden border border-zinc-800 transition-all ${config.aggressiveFps ? 'bg-black' : 'bg-zinc-950'}`}>
      <div className="absolute top-4 left-4 flex gap-4 text-[10px] font-mono text-zinc-500 z-10">
        <div>SCORE: <span className="text-white">{score}</span></div>
        <div>HITS: <span className="text-green-500">{hits}</span></div>
        <div>MISSES: <span className="text-red-500">{misses}</span></div>
        <div>ACC: <span className="text-blue-500">{hits + misses === 0 ? 0 : Math.round((hits / (hits + misses)) * 100)}%</span></div>
        {config.aggressiveFps && (
          <div className="flex items-center gap-1.5 bg-blue-600/20 border border-blue-500/30 px-2 py-0.5 rounded-full animate-pulse">
            <Zap className="w-2.5 h-2.5 text-blue-400 fill-current" />
            <span className="text-[9px] font-bold text-blue-400 tracking-wider">FPS_BOOST</span>
          </div>
        )}
      </div>

      <div className="absolute top-4 right-4 flex gap-1.5 z-10">
        <button
          onClick={() => setMode('flick')}
          className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all ${mode === 'flick' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'bg-zinc-900 text-zinc-500 border border-zinc-800 hover:bg-zinc-800'}`}
        >
          FLICK
        </button>
        <button
          onClick={() => setMode('track')}
          className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all ${mode === 'track' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'bg-zinc-900 text-zinc-500 border border-zinc-800 hover:bg-zinc-800'}`}
        >
          TRACK
        </button>
      </div>

      <canvas
        ref={canvasRef}
        width={800}
        height={500}
        onClick={handleCanvasClick}
        onPointerDown={handleCanvasPointerDown}
        className={`w-full h-full cursor-none ${config.graphicsProfile === 'mine' ? 'image-render-pixelated' : ''}`}
        style={{
          filter: config.graphicsProfile === 'mine' ? 'contrast(1.2) brightness(1.1)' : config.graphicsProfile === 'polished' ? 'drop-shadow(0 0 10px rgba(255,255,255,0.1))' : 'none'
        }}
      />

      {/* Aim Tracking Guide */}
      {config.aimTracking && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 pointer-events-none text-[9px] font-bold text-blue-500/70 flex flex-col items-center gap-1">
          <div className="animate-bounce tracking-widest uppercase">Fluid Pull-Up Suggested</div>
          <div className="w-0.5 h-10 bg-gradient-to-t from-blue-500/50 to-transparent" />
        </div>
      )}

      {/* Radar Tático */}
      {config.radarEnabled && (
        <div className="absolute bottom-4 right-4 w-32 h-32 bg-black/60 border border-zinc-800 rounded-lg backdrop-blur-sm overflow-hidden flex items-center justify-center">
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-full h-[1px] bg-zinc-800" />
            <div className="h-full w-[1px] bg-zinc-800" />
            <div className="absolute w-full h-full border border-zinc-800 rounded-full scale-50" />
          </div>
          <div className="relative w-full h-full">
            {targets.map(t => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="absolute w-1.5 h-1.5 bg-red-500 rounded-full shadow-[0_0_5px_rgba(239,68,68,0.8)]"
                style={{
                  left: `${(t.x / 800) * 100}%`,
                  top: `${(t.y / 500) * 100}%`,
                  transform: 'translate(-50%, -50%)'
                }}
              />
            ))}
            {/* Player position */}
            <div className="absolute top-1/2 left-1/2 w-2 h-2 bg-blue-500 rounded-full -translate-x-1/2 -translate-y-1/2 shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
          </div>
          <div className="absolute top-1 left-1 text-[8px] font-bold text-zinc-500 uppercase tracking-tighter">Radar_AI</div>
        </div>
      )}

      {/* Mouse following crosshair */}
      <MouseCrosshair config={config} targets={targets} />
    </div>
  );
};

const MouseCrosshair = ({ config, targets }: { config: CrosshairConfig, targets: Target[] }) => {
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const lastPos = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const canvas = document.querySelector('canvas');
      if (!canvas) return;
      const rect = canvas.getBoundingClientRect();
      
      let targetX = e.clientX;
      let targetY = e.clientY;

      // Sensitivity Stabilizer: Smoothing
      if (config.sensitivityStabilizer) {
        targetX = lastPos.current.x + (targetX - lastPos.current.x) * 0.4;
        targetY = lastPos.current.y + (targetY - lastPos.current.y) * 0.4;
      }

      // Aim Stabilizer: Magnetic Pull
      if (config.aimStabilizer && targets.length > 0) {
        const mouseX = targetX - rect.left;
        const mouseY = targetY - rect.top;
        
        let nearestTarget = null;
        let minDist = Infinity;

        targets.forEach(t => {
          const dist = Math.sqrt((mouseX - t.x) ** 2 + (mouseY - t.y) ** 2);
          if (dist < 100 && dist < minDist) {
            minDist = dist;
            nearestTarget = t;
          }
        });

        if (nearestTarget) {
          // Pull 15% towards target center
          const pullFactor = 0.15;
          targetX = targetX + ((nearestTarget.x + rect.left) - targetX) * pullFactor;
          targetY = targetY + ((nearestTarget.y + rect.top) - targetY) * pullFactor;
        }
      }

      if (
        e.clientX >= rect.left &&
        e.clientX <= rect.right &&
        e.clientY >= rect.top &&
        e.clientY <= rect.bottom
      ) {
        setPos({ x: targetX, y: targetY });
        lastPos.current = { x: targetX, y: targetY };
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [config.sensitivityStabilizer, config.aimStabilizer, targets]);

  return (
    <div
      className="fixed pointer-events-none z-50"
      style={{
        left: pos.x,
        top: pos.y,
        transform: 'translate(-50%, -50%)',
      }}
    >
      <Crosshair config={config} />
    </div>
  );
};
