import React from 'react';
import { CrosshairConfig } from '../types';

interface CrosshairProps {
  config: CrosshairConfig;
  className?: string;
}

export const Crosshair: React.FC<CrosshairProps> = ({ config, className }) => {
  const {
    shape,
    size,
    thickness,
    gap,
    color,
    opacity,
    outline,
    outlineColor,
    outlineThickness,
    dot,
    dotSize,
    dotColor,
  } = config;

  const renderOutline = (children: React.ReactNode) => {
    if (!outline) return children;
    return (
      <div style={{ position: 'relative' }}>
        <div
          style={{
            position: 'absolute',
            top: -outlineThickness,
            left: -outlineThickness,
            right: -outlineThickness,
            bottom: -outlineThickness,
            filter: `drop-shadow(0 0 ${outlineThickness}px ${outlineColor})`,
            zIndex: -1,
          }}
        >
          {children}
        </div>
        {children}
      </div>
    );
  };

  const commonStyle: React.CSSProperties = {
    backgroundColor: color,
    opacity: opacity,
    position: 'absolute',
  };

  const renderCrosshair = () => {
    switch (shape) {
      case 'dot':
        return (
          <div
            style={{
              width: size,
              height: size,
              backgroundColor: color,
              opacity: opacity,
              borderRadius: '50%',
            }}
          />
        );

      case 'circle':
        return (
          <div
            style={{
              width: size * 2,
              height: size * 2,
              border: `${thickness}px solid ${color}`,
              opacity: opacity,
              borderRadius: '50%',
            }}
          />
        );

      case 'square':
        return (
          <div
            style={{
              width: size * 2,
              height: size * 2,
              border: `${thickness}px solid ${color}`,
              opacity: opacity,
            }}
          />
        );

      case 't-shape':
      case 'cross':
        return (
          <div className="relative flex items-center justify-center">
            {/* Top */}
            {shape !== 't-shape' && (
              <div
                style={{
                  ...commonStyle,
                  width: thickness,
                  height: size,
                  bottom: gap,
                }}
              />
            )}
            {/* Bottom */}
            <div
              style={{
                ...commonStyle,
                width: thickness,
                height: size,
                top: gap,
              }}
            />
            {/* Left */}
            <div
              style={{
                ...commonStyle,
                width: size,
                height: thickness,
                right: gap,
              }}
            />
            {/* Right */}
            <div
              style={{
                ...commonStyle,
                width: size,
                height: thickness,
                left: gap,
              }}
            />
            {/* Center Dot */}
            {dot && (
              <div
                style={{
                  width: dotSize,
                  height: dotSize,
                  backgroundColor: dotColor,
                  borderRadius: '50%',
                  position: 'absolute',
                }}
              />
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={`flex items-center justify-center ${className}`}>
      {renderCrosshair()}
    </div>
  );
};
