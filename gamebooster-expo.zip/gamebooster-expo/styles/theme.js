export const theme = {
  bg: "#0A0015",
  neon: "#B026FF",
  text: "#FFFFFF",
  sub: "#AAAAAA"
};
