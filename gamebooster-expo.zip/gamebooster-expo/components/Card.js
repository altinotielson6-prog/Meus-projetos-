import { View, Text, StyleSheet } from "react-native";
import { theme } from "../styles/theme";

export default function Card({ title, children }) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderColor: theme.neon,
    borderRadius: 12,
    padding: 15,
    marginVertical: 10,
  },
  title: {
    color: theme.text,
    fontWeight: "bold",
    marginBottom: 10,
  },
});
