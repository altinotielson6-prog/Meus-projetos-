import { useState } from "react";
import { View, TouchableOpacity, Text, StyleSheet } from "react-native";
import HomeScreen from "./screens/HomeScreen";
import FocusScreen from "./screens/FocusScreen";
import StatsScreen from "./screens/StatsScreen";
import { theme } from "./styles/theme";

export default function App() {
  const [screen, setScreen] = useState("home");

  const renderScreen = () => {
    if (screen === "focus") return <FocusScreen />;
    if (screen === "stats") return <StatsScreen />;
    return <HomeScreen />;
  };

  return (
    <View style={{ flex: 1 }}>
      {renderScreen()}

      <View style={styles.tabs}>
        <TouchableOpacity onPress={() => setScreen("home")}>
          <Text style={styles.tab}>Home</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setScreen("focus")}>
          <Text style={styles.tab}>Foco</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setScreen("stats")}>
          <Text style={styles.tab}>Stats</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  tabs: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 15,
    backgroundColor: "#000",
  },
  tab: {
    color: theme.neon,
    fontWeight: "bold",
  },
});
