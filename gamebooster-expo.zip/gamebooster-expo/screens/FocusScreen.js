import { View, Text, StyleSheet, Alert } from "react-native";
import NeonButton from "../components/NeonButton";
import { theme } from "../styles/theme";

export default function FocusScreen() {

  const openSettings = () => {
    Alert.alert(
      "Modo Foco",
      "Abra as configurações do sistema e limite apps em segundo plano."
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Modo Foco</Text>

      <NeonButton
        title="ABRIR CONFIGURAÇÕES"
        onPress={openSettings}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.bg,
    padding: 20,
  },
  title: {
    color: theme.text,
    fontSize: 22,
    fontWeight: "bold",
  },
});
