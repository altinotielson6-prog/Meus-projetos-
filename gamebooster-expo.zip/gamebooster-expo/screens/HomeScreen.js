import { View, Text, StyleSheet, Alert } from "react-native";
import Card from "../components/Card";
import NeonButton from "../components/NeonButton";
import { theme } from "../styles/theme";

export default function HomeScreen() {

  const handleBoost = () => {
    Alert.alert(
      "🚀 Boost concluído",
      "✔ Apps em background reduzidos\n✔ Rede priorizada\n✔ Sistema otimizado 😈"
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>GAME BOOSTER</Text>

      <Card title="⚡ Otimização">
        <NeonButton title="ATIVAR BOOST" onPress={handleBoost} />
      </Card>

      <Card title="🌐 Modo Foco">
        <Text style={styles.text}>
          Limite apps em segundo plano para melhorar o desempenho.
        </Text>
      </Card>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.bg,
    padding: 20,
  },
  title: {
    color: theme.text,
    fontSize: 24,
    fontWeight: "bold",
  },
  text: {
    color: theme.sub,
  },
});
