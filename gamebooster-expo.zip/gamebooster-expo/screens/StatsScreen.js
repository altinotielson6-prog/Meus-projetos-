import { View, Text, StyleSheet } from "react-native";
import { theme } from "../styles/theme";

export default function StatsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Estatísticas</Text>

      <Text style={styles.text}>Tempo jogado: 1h 20min</Text>
      <Text style={styles.text}>FPS médio: ~58</Text>
      <Text style={styles.text}>Desempenho: Estável</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.bg,
    padding: 20,
  },
  title: {
    color: theme.text,
    fontSize: 22,
    fontWeight: "bold",
  },
  text: {
    color: theme.sub,
    marginTop: 10,
  },
});
